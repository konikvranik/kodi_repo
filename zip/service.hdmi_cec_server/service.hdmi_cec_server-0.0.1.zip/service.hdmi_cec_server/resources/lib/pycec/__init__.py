"""pyCEC"""
import logging

_LOGGER = logging.getLogger(__name__)

DEFAULT_PORT = 9526
DEFAULT_HOST = '0.0.0.0'
